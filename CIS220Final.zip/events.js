/*
   New Perspectives on HTML, CSS, and JavaScript
   Tutorial 12
   Tutorial Case

   The dayEvent array contains a list of CCC events in July
*/

var dayEvent = new Array();

dayEvent[1] = "<br /> Kids Eat Free<br />After 4pm w/adult entree";
dayEvent[2] = "<br /> Magic Night";
dayEvent[3] = "<br />Art Party<br />6:30 pm";
dayEvent[4] = "<br />Live Music";
dayEvent[5] = "<br />Live Music";
dayEvent[6] = "<br />CCC Jazz Band<br />7 pm<br />$7";
dayEvent[7] = "<br />Burger Day";



dayEvent[8] = "<br /> Kids Eat Free<br />After 4pm w/adult entree";
dayEvent[9] = "<br /> Magic Night";
dayEvent[10] = "";
dayEvent[11] = "<br />Live Music";
dayEvent[12] = "<br />Classics Brunch<br />11 am<br />$12";
dayEvent[13] = "";
dayEvent[14] = "<br /> Raffle";

dayEvent[15] = "<br /> Kids Eat Free<br />After 4pm w/adult entree";
dayEvent[16] = "<br /> Magic Night";
dayEvent[17] = "";
dayEvent[18] = "<br />Live Music";
dayEvent[19] = "<br />Live Music";
dayEvent[20] = "";
dayEvent[21] = "<br />Raffle";

dayEvent[22] = "<br /> Kids Eat Free<br />After 4pm w/adult entree";
dayEvent[23] = "<br /> Magic Night";
dayEvent[24] = "";
dayEvent[25] = "<br />Live Music";
dayEvent[26] = "<br />Classics Brunch<br />11 am<br />$12";
dayEvent[27] = "";
dayEvent[28] = "<br /> Raffle";
dayEvent[29] = "<br /> Kids Eat Free<br />After 4pm w/adult entree";
dayEvent[30] = "<br /> Magic Night";
dayEvent[31] = "";
